package ejercicio7;

import java.util.Scanner;

/**
 * Clase principal que contiene el main
 * @author Irene Guerrero
 */
public class RueDelPercebe {

	/**
	 * Función que te pide el número de casas y de pisos por teclado y te las pinta en la consola.
	 * @param args sin uso
	 */
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		byte casasPiso=0;
		byte numeroPlantas=0;
		System.out.println("Te voy a construir un edificio, dime el número de casas");		
		casasPiso=Byte.parseByte(sc.nextLine());
		System.out.println("Ahora dime el número de plantas");
		numeroPlantas=Byte.parseByte(sc.nextLine());
		
		System.out.println("|--------------------|");
		System.out.println("| 13 Rue del Percebe |");
		System.out.println("|--------------------|");
		
		for (byte i=0;i<numeroPlantas;i++) {
			System.out.print(Funciones.pintarAltura("|-----|", casasPiso));
			System.out.print(Funciones.pintarAltura("|     |", casasPiso));
			System.out.print(Funciones.pintarAltura("|     |", casasPiso));
		}
		
	}

}
