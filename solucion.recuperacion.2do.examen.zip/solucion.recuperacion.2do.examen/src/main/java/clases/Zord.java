package clases;

import enums.Color;

public class Zord extends ElementoConColor{

	public Zord(String nombre, Color color) {
		super(nombre, color);
	}

	@Override
	public String toString() {
		return this.getNombre()+" ("+super.toString()+")";
	}

	
	
}
