package principal;

import java.util.Scanner;

import enums.Color;
import clases.Zord;
import clases.Base;
import clases.PowerRanger;
import java.util.ArrayList;

public class GoGoPowerRangers {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<Zord> zordsBase=new ArrayList<Zord>();
		
		zordsBase.add(new Zord("Tiranozord",Color.ROJO));
		zordsBase.add(new Zord("Mastodonzord",Color.NEGRO));
		zordsBase.add(new Zord("Tricerazord",Color.AZUL));
		zordsBase.add(new Zord("Sabrezord",Color.AMARILLO));
		zordsBase.add(new Zord("Pterodactzord",Color.ROSA));
		zordsBase.add(new Zord("Dragonzord",Color.VERDE));
		zordsBase.add(new Zord("Tigrezord",Color.BLANCO));
		
		Base centroDeMando=new Base("Centro de Mando",zordsBase);
		
		System.out.println("Dime el nombre de un nuevo zord");
		String nombreZord=sc.nextLine();
		
		System.out.println(Color.imprimirMenuSeleccionColor());
		byte opcion=Byte.parseByte(sc.nextLine());
		Color colorZord=Color.opcionNumericaAColor(opcion);
		centroDeMando.getZordsAlmacenados().add(new Zord(nombreZord,colorZord));
		
		System.out.println("Dime el nombre del Power Ranger");
		String nombreRanger=sc.nextLine();
		System.out.println(Color.imprimirMenuSeleccionColor());
		opcion=Byte.parseByte(sc.nextLine());
		Color colorRanger=Color.opcionNumericaAColor(opcion);
		
		PowerRanger ranger=new PowerRanger(nombreRanger,colorRanger);
		ranger.asignarZord(centroDeMando);
		System.out.println(ranger+"\n");
		ranger.devolverZord(centroDeMando);
		System.out.println(ranger);
		
		
	}

}
