package apuntes1DAM;

import javax.swing.JOptionPane;

public class JOptionPane2 {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Su ordenador tiene un Ransomware", "Error grave",
				JOptionPane.INFORMATION_MESSAGE);

	}

}
