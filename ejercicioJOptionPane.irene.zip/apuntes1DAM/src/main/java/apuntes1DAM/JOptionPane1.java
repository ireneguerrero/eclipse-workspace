package apuntes1DAM;

import javax.swing.JOptionPane;

public class JOptionPane1 {

	public static void main(String[] args) {
		String nombre = "Irene";
		JOptionPane.showMessageDialog(null, "Bienvenido " + nombre);

	}

}
