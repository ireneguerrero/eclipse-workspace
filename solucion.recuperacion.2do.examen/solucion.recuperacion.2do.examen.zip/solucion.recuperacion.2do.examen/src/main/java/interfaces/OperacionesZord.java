package interfaces;

import clases.Base;

public interface OperacionesZord {
	public boolean asignarZord(Base b);
	public boolean devolverZord(Base b);
}
