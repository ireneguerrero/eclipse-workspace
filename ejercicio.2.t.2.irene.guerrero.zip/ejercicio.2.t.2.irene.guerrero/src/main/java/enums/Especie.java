package enums;

public enum Especie {
	PERRO,GATO,DRAGON,POLLITO
}
