package excepciones;

public class ApellidoConNumerosException extends Exception {
	public ApellidoConNumerosException(String mensaje) {
		super(mensaje);
	}
}
