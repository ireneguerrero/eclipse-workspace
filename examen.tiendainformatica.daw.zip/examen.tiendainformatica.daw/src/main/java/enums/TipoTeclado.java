package enums;

public enum TipoTeclado {
	REDUCIDO,
	MULTIMEDIA

}
