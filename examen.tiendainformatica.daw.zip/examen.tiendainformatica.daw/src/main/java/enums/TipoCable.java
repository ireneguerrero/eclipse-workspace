package enums;

public enum TipoCable {
	HDMI,
	DVI,
	VGA,
	USB_2,
	USB_3,
	USB_C,
	WIRELESS

}
