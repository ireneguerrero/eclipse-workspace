package enums;

public enum Resoluciones {
	SD,
	QHD,
	HD,
	FHD,
	K_4,
	K_8

}
