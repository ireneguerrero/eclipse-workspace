package utils;

public class Config {
	public static final boolean verboseMode = true;
}
