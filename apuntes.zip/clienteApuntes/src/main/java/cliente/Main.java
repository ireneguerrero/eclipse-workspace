package cliente;

import interfaces.Ventana;

public class Main {

	public static void main(String[] args) {
		Ventana v = new Ventana();
		
	}
}
