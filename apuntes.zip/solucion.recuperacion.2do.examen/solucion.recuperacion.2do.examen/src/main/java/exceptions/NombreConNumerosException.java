package exceptions;

public class NombreConNumerosException extends Exception {
	public NombreConNumerosException(String mensaje) {
		super(mensaje);
	}

}
