package exceptions;

public class NombreZordInvalidoException extends Exception {
	public NombreZordInvalidoException(String mensaje) {
		super(mensaje);
	}
}
