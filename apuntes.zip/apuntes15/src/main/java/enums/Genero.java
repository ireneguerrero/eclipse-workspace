package enums;

public enum Genero {
	HOMBRE, MUJER, NEUTRO
}
