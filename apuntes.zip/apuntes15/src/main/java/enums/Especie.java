package enums;

public enum Especie {
	GATO, PERRO, PAVO_REAL
}
