package clases;

public interface VenderFicha {
	public void venderFicha();
}
