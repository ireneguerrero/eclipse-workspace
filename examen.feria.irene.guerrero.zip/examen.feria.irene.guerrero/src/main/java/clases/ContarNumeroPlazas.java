package clases;

public interface ContarNumeroPlazas {
	public byte numeroTotalPlazas();
}
