package enums;

public enum TematicaVehiculo {
	COCHE_BOMBEROS, AMBULANCIA, COCHE_BATMAN, COHETE, SUPERMAN
}
