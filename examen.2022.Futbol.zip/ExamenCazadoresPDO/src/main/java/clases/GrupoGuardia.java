package clases;

import enums.Peligrosidad;

public class GrupoGuardia extends Grupo {

	public GrupoGuardia(String nombre, Peligrosidad peligrosidad) {
		super(nombre, peligrosidad);
		// TODO Auto-generated constructor stub
	}


	
	
}
