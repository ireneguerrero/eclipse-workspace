package enums;

public enum Peligrosidad {
	LEVE,
	MODERADA,
	GRAVE
}
