package exceptions;

public class GeneroVacioException extends Exception {
	public GeneroVacioException(String mensaje) {
		super(mensaje);
	}

}
