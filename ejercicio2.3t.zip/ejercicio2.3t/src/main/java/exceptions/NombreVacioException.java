package exceptions;

public class NombreVacioException extends Exception {
	public NombreVacioException(String mensaje) {
		super(mensaje);
	}

}
